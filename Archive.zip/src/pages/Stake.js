import Footer from "../components/Footer";
import Header from "../components/Header";
import {useEffect, useState} from 'react'

import LogoTransparent from '../static/media/logo_transparent.svg';
import logo from '../static/media/logo.svg'
import SGAJ_DOLLY_LP from '../static/media/busd-usdt.svg'
import SGAJ_BNB_LP from '../static/media/busd-usdt.svg'
import SGAJ_BUSD_LP from '../static/media/busd-usdt.svg'
import SGAJ from '../static/media/busd-usdt.svg'

import SGAJ_LP from '../static/media/busd-usdt.svg'
import BUSD_USDT from '../static/media/busd-usdt.svg'
import UST_LP from '../static/media/ust-pool.png'
import DOLLY_LP from '../static/media/busd-usdt.svg'
import walletIcon from '../static/media/bank-account.svg'
import lockIcon from '../static/media/lock-icon.svg'

import Portfolio from '../static/media/beginner-apeboard-image.png'
import Buy from '../static/media/beginner-apeboard-image.png'
import Chart from '../static/media/beginner-apeboard-image.png'
import TokenToggle from "../components/Stake/TokenToggle";
// const puppeteer = require('puppeteer')


function Stake() {
    const [Apr, setApr] = useState(undefined)
    // useEffect(() => {
    //     async function scrapeApr(){
    //         const browser = await puppeteer.launch();
    //         const page = await browser.newPage();
    //         await page.goto('https://polygaj.finance/farms')

    //         const [el] = page.$x('//*[@id="root"]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[3]/div[2]/text()[1]');
    //         console.log(el)
    //     }
    //     scrapeApr()
    // }, [])
    return (
        <div>
            <Header inApp={true} active='Stake' />
            <div className="container">
                <div className=" dark:bg-dark-700 bg-white rounded-3xl shadow-md p-6 lg:p-12 mb-6">
                    <div className="grid grid-cols-2 gap-3 py-2">
                        <div className="grid grid-cols-8 py-8 sm:py-0 col-span-2 sm:col-span-1  items-center rounded-3xl bg-gradient-to-r from-blue-400 to-green-300 justify-between">
                            <div className="col-span-5 pl-5 sm:pl-6 ">
                                <div className="text-xl font-bold text-white mb-3">
                                    <a href="https://exchange.pancakeswap.finance/?#/swap?outputCurrency=0x844fa82f1e54824655470970f7004dd90546bb28" target="_blank">StableGaj </a>
            earned :
          </div>
                                <div className="text-4xl font-bold text-white mb-2">0.00</div>
                                <div className="text-sm font-bold text-white">≈ $0.00</div>
                            </div>
                            <div className="col-span-3 px-2 pr-6">
                                <div style={{ display: 'inline-block', maxWidth: '100%', overflow: 'hidden', position: 'relative', boxSizing: 'border-box', margin: 0 }}>
                                    <div style={{ boxSizing: 'border-box', display: 'block', maxWidth: '100%' }}>
                                        <img alt aria-hidden="true" role="presentation" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iTmFOIiBoZWlnaHQ9IjE2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2ZXJzaW9uPSIxLjEiLz4=" style={{ maxWidth: '100%', display: 'block', margin: 0, border: 'none', padding: 0 }} />
                                    </div>
                                    <img src={LogoTransparent} decoding="async" style={{ visibility: 'inherit', position: 'absolute', inset: 0, boxSizing: 'border-box', padding: 0, border: 'none', margin: 'auto', display: 'block', width: 0, height: 0, minWidth: '100%', maxWidth: '100%', minHeight: '100%', maxHeight: '100%' }} srcSet={LogoTransparent} />
                                </div>
                            </div>
                        </div>
                        <div className="dark:text-white col-span-2 sm:col-span-1 rounded-3xl py-8 sm:py-6 px-3 sm:px-8 font-bold">
                            <div className="grid grid-cols-12">
                                <div className="col-span-1">
                                    <div style={{ display: 'inline-block', maxWidth: '100%', overflow: 'hidden', position: 'relative', boxSizing: 'border-box', margin: 0 }}>
                                        <div style={{ boxSizing: 'border-box', display: 'block', maxWidth: '100%' }}>
                                            <img alt aria-hidden="true" role="presentation" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgiIGhlaWdodD0iMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIi8+" style={{ maxWidth: '100%', display: 'block', margin: 0, border: 'none', padding: 0 }} />
                                        </div>
                                        <img src={walletIcon} decoding="async" style={{ visibility: 'inherit', position: 'absolute', inset: 0, boxSizing: 'border-box', padding: 0, border: 'none', margin: 'auto', display: 'block', width: 0, height: 0, minWidth: '100%', maxWidth: '100%', minHeight: '100%', maxHeight: '100%' }} srcSet={walletIcon}/>
                                    </div>
                                </div>
                                <div className="sm:text-lg text-md ml-2 col-span-11 flex sm:block items-center ">
                                    <div className="inline sm:block">Your sGAJ&nbsp;</div>
                                    <div className="inline sm:block">wallet balance :</div>
                                </div>
                                <div className="col-span-1" />
                                <div className="ml-2 col-span-11">
                                    <div className="text-4xl mt-4 mb-2 font-bold text-blue-500">0.00</div>
                                    <div className="text-sm mb-4 ">≈ $0.00</div>
                                </div>
                                <div className="col-span-1">
                                    <div style={{ display: 'inline-block', maxWidth: '100%', overflow: 'hidden', position: 'relative', boxSizing: 'border-box', margin: 0 }}>
                                        <div style={{ boxSizing: 'border-box', display: 'block', maxWidth: '100%' }}>
                                            <img alt aria-hidden="true" role="presentation" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgiIGhlaWdodD0iMjgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIi8+" style={{ maxWidth: '100%', display: 'block', margin: 0, border: 'none', padding: 0 }} />
                                        </div>
                                        <img src={lockIcon} decoding="async" style={{ visibility: 'inherit', position: 'absolute', inset: 0, boxSizing: 'border-box', padding: 0, border: 'none', margin: 'auto', display: 'block', width: 0, height: 0, minWidth: '100%', maxWidth: '100%', minHeight: '100%', maxHeight: '100%' }} srcSet={lockIcon}/>
                                    </div>
                                </div>
                                <div className="ml-2 col-span-11 ">
                                    <div className="sm:text-lg text-md  flex items-center  py-1 sm:py-0">
                                        <div className="sm:flex">Total Value Locked :&nbsp;</div>
                                    </div>
                                    <div className>
                                        <div className="text-4xl my-4 font-bold text-blue-500">
                                            -
              </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div className="container">
                <div className="text-center font-bold text-4xl pt-10 mt-10 pb-10 mb-5 dark:text-white">
                    <span className="text-blue-400">Stake</span> your LP tokens to earn <span className="text-blue-400">sGAJ</span>
                    <div className="text-sm font-normal sm:px-40 mt-2">
                        Stake your LP tokens in the farming pools to earn sGAJ as a reward. LP
                        tokens can be withdraw at any time. However, they must be staked to earn
                        yield.
                </div>
            </div>
            </div>
            <div className="container">
                <div className="dark:bg-dark-700 bg-white rounded-3xl shadow-md py-6 lg:pt-6 mb-6">
                    <div className="text-base sm:text-2xl font-bold dark:text-white ml-4 sm:ml-6 mb-4">
                        Staking sGAJ
      </div>
                    <div className="text-sm sm:text-base dark:border-0 border-t grid grid-cols-5 dark:text-white dark:border-t-dark-500 py-4 ">
                        <div className="col-span-2 text-center sm:text-left sm:ml-6 ">
                            LP Tokens Name
        </div>
                        <div className="col-span-1 text-center">APR</div>
                        <div className="col-span-1 text-center">TVL</div>
                        <div className="col-span-1 text-center">Earned</div>
                    </div>
                    <TokenToggle name="sGAJ-USDC LPs" logo={SGAJ_BUSD_LP} APR="306" APRDaily="0.84" TVL="6,908,333" Earned="0.00"/>
                    <TokenToggle name="sGAJ" logo={logo} APR="37" APRDaily="0.10" TVL="28,122,464" Earned="0.00"/>
                    

                </div>
                <div className="dark:bg-dark-700 bg-white rounded-3xl shadow-md py-6 lg:pt-6 mb-6">
                    <div className="text-base sm:text-2xl font-bold dark:text-white ml-4 sm:ml-6 mb-4">
                        Staking Stablecoin
      </div>
                    <div className="text-sm sm:text-base dark:border-0 border-t grid grid-cols-5 dark:text-white dark:border-t-dark-500 py-4 ">
                        <div className="col-span-2 text-center sm:text-left sm:ml-6 ">
                            LP Tokens Name
        </div>
                        <div className="col-span-1 text-center">APR</div>
                        <div className="col-span-1 text-center">TVL</div>
                        <div className="col-span-1 text-center">Earned</div>
                    </div>
                    <TokenToggle name="sGAJ LPs" logo={SGAJ_LP} APR="74" APRDaily="0.20" TVL="14,630,037" Earned="0.00"/>

                </div>
                
                
            </div>



            <Footer />
        </div>
    );
}

export default Stake;