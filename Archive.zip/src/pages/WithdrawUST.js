/* eslint-disable */
import Footer from "../components/Footer";
import Header from "../components/Header";

import React, { useEffect, useState } from 'react';
// import { usdcBalance } from '../hooks/usdcBalance'
import { getWeb3 } from '../hooks/utils.js';
import bankAccount from '../static/media/bank-account.svg'
import erc20 from '../Abi/erc20.json'
import DAI from '../static/media/dai.svg'
import USDT from '../static/media/usdt.svg'
import USDC from '../static/media/usdc.svg'
import FRAX from '../static/media/frax.png'
import USTPool from '../static/media/ust-pool.png'
import RadioToken from "../components/WithdrawUST/RadioToken";
import SwapAbi from '../Abi/SwapAbi.json'

function WithdrawUST() {
    const [FRAXSelected, setFRAXSelected] = useState(false);
    const [USDTSelected, setUSDTSelected] = useState(false);
    const [USDCSelected, setUSDCSelected] = useState(false);
    const [DAISelected, setDAISelected] = useState(false);
    
    const [USDCApproved, setUSDCApproved] = useState(false);
    const [USDTApproved, setUSDTApproved] = useState(false);
    const [DAIApproved, setDAIApproved] = useState(false);
    const [FRAXApproved, setFRAXApproved] = useState(false);
    const [approvedLP, setApprovedLP] = useState(false)

    const [swapContract, setSwapContract] = useState(undefined)
    const [web3, setWeb3] = useState(undefined);
    const [accounts, setAccounts] = useState(undefined);
    const [usdcContract, setUsdcContract] = useState(undefined);
    const [fraxContract, setFraxContract] = useState(undefined);
    const [usdtContract, setUsdtContract] = useState(undefined);
    const [daiContract, setDaiContract] = useState(undefined);
    const [stablegajLPContract, setStablegajLPContract] = useState(undefined);
    
    const [usdcBalance, setUsdcBalance] = useState(0);
    const [fraxBalance, setFraxBalance] = useState(0);
    const [daiBalance, setDaiBalance] = useState(0);
    const [usdtBalance, setUsdtBalance] = useState(0);
    const [stablegajBalance, setStablegajBalance] = useState(0);
    const [oneTokenBalance, setOneTokenBalance] = useState(0)

    const [USDCToWithdraw, setUSDCToWithdraw] = useState(0)
    const [USDTToWithdraw, setUSDTToWithdraw] = useState(0)
    const [DAIToWithdraw, setDAIToWithdraw] = useState(0)
    const [FRAXToWithdraw, setFRAXToWithdraw] = useState(0)


  useEffect(() => {
    const init = async () => {
      const web3 = await getWeb3();
      const accounts = await web3.eth.getAccounts();
      const networkId = await web3.eth.net.getId();
      const usdc = new web3.eth.Contract(
        erc20,
        '0x2791bca1f2de4661ed88a30c99a7a9449aa84174',
      );
      const frax = new web3.eth.Contract(
        erc20,
        '0x104592a158490a9228070e0a8e5343b499e125d0',
      );
      const dai = new web3.eth.Contract(
        erc20,
        '0x8f3cf7ad23cd3cadbd9735aff958023239c6a063',
      );
      const usdt = new web3.eth.Contract(
        erc20,
        '0xc2132d05d31c914a87c6611c10748aeb04b58e8f',
      );
      
      const Swapabi = new web3.eth.Contract(
        SwapAbi.abi,
        '0x6bcA12b7a56f19cEB8eaE4d11CCbfb7653Afd0F4',
      );
      const stablegajLP = new web3.eth.Contract(
        erc20,
        '0xe7733b7785acf9c160b37e8038aab6a54cd26cc4',
      );

    const usdcBal = await usdc.methods
        .balanceOf(accounts[0])
        .call();
    const fraxBal = await frax.methods
        .balanceOf(accounts[0])
        .call();
    const daiBal = await dai.methods
        .balanceOf(accounts[0])
        .call();
    const usdtBal = await usdt.methods
        .balanceOf(accounts[0])
        .call();
    const stablegajLPBal = await stablegajLP.methods
        .balanceOf(accounts[0])
        .call();

    const allowance = await stablegajLP.methods.allowance(accounts[0], '0x6bcA12b7a56f19cEB8eaE4d11CCbfb7653Afd0F4').call()
    if (allowance == '10000000000000000000000000'){
        setApprovedLP(true)
    } else {
        setApprovedLP(false)
    }
    const stablegajLPBalance = stablegajLPBal / 10**18;
    const usdcBalance = usdcBal / 1000000;
    const fraxBalance = fraxBal / 10**18;
    const daiBalance = daiBal / 10**18;
    const usdtBalance = usdtBal / 10**6;
    console.log(usdcBalance)
      setWeb3(web3);
      setAccounts(accounts);
      setUsdcContract(usdc);
      setFraxContract(frax);
      setUsdtContract(usdt);
      setStablegajLPContract(stablegajLP);
      

      setDaiContract(dai);
      setUsdcBalance(usdcBalance);
      setFraxBalance(fraxBalance);
      setStablegajBalance(stablegajLPBalance);
      setDaiBalance(daiBalance);
      setUsdtBalance(usdtBalance);
      setSwapContract(Swapabi);
    }
    init();
    window.ethereum.on('accountsChanged', accounts => {
      setAccounts(accounts);
    });
  }, []);

    // async function calcFRAXTokenLiq(){
    //     const amount = oneTokenBalance.mul(web3.utils.toBN(10).pow(18))
    //     const cal = await swapContract.methods.calculateRemoveLiquidityOneToken(accounts[0], amount, 0).call()
    //     setOneTokenBalance(cal/18)
    // }

    // async function calcDAITokenLiq(){
    //     const amount = oneTokenBalance.mul(web3.utils.toBN(10).pow(18))
    //     const cal = await swapContract.methods.calculateRemoveLiquidityOneToken(accounts[0], amount, 1).call()
    //     setOneTokenBalance(cal.div(web3.utils.toBN(10).pow(18)))
    // }

    // async function calcUSDCTokenLiq(){
    //     const amount = stablegajBalance.mul(web3.utils.toBN(10).pow(18))
    //     const cal = await swapContract.methods.calculateRemoveLiquidityOneToken(accounts[0], amount, 2).call()
    //     setOneTokenBalance(calc.div(web3.utils.toBN(10).pow(6)))
    // }

    // async function calcUSDTTokenLiq(){
    //     const amount = stablegajBalance.mul(web3.utils.toBN(10).pow(18))
    //     const cal = await swapContract.methods.calculateRemoveLiquidityOneToken(accounts[0], amount, 3).call()
    //     setOneTokenBalance(calc.div(web3.utils.toBN(10).pow(6)))
    // }

    const select = (token) => {
        if (token === "FRAX") {
            setFRAXSelected(true);
            setUSDTSelected(false);
            setDAISelected(false);
            setUSDCSelected(false);
            // calcFRAXTokenLiq();
        }
        if (token === "USDT") {
            setFRAXSelected(false);
            setUSDTSelected(true);
            setDAISelected(false);
            setUSDCSelected(false);
            // calcUSDTTokenLiq();
        }
        if (token === "DAI") {
            setFRAXSelected(false);
            setUSDTSelected(false);
            setDAISelected(true);
            setUSDCSelected(false);
            // calcDAITokenLiq();
        }
        if (token === "USDC") {
            setFRAXSelected(false);
            setUSDTSelected(false);
            setDAISelected(false);
            setUSDCSelected(true);
            // calcUSDCTokenLiq();
        }
    }

    useEffect(() => {

    },[USDCToWithdraw, USDTToWithdraw, DAIToWithdraw, FRAXToWithdraw])

    return (
        <div>
            <Header inApp={true} active="Withdraw" />
            <div className="container">
                <div className="w-20">
                    <a href="/Withdraw"><div className="text-blue-400 mt-3 ">
                        <div className="flex items-center w-auto">
                            <div style={{ display: 'inline-block', maxWidth: '100%', overflow: 'hidden', position: 'relative', boxSizing: 'border-box', margin: 0 }}>
                                <div style={{ boxSizing: 'border-box', display: 'block', maxWidth: '100%' }}>
                                    <img alt aria-hidden="true" role="presentation" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iMTQiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIi8+" style={{ maxWidth: '100%', display: 'block', margin: 0, border: 'none', padding: 0 }} />
                                </div>
                                <img src="/_next/image?url=%2Fimages%2Ficons%2Farrow-left.svg&w=32&q=75" decoding="async" style={{ visibility: 'inherit', position: 'absolute', inset: 0, boxSizing: 'border-box', padding: 0, border: 'none', margin: 'auto', display: 'block', width: 0, height: 0, minWidth: '100%', maxWidth: '100%', minHeight: '100%', maxHeight: '100%' }} srcSet="
          /_next/image?url=%2Fimages%2Ficons%2Farrow-left.svg&w=16&q=75 1x,
          /_next/image?url=%2Fimages%2Ficons%2Farrow-left.svg&w=32&q=75 2x
        " />
                            </div>
                        </div>
                    </div></a>
                </div>
                <div className="dark:text-white text-3xl font-bold mb-6 mt-3">Withdraw</div>
                <div className="grid grid-cols-2 gap-7">
                    <div className="col-span-full sm:col-span-1 w-full">
                        <div className="dark:bg-dark-700 dark:text-white rounded-3xl shadow-md p-6 lg:p-10 py-4  bg-white">
                            <div className="gap-3 ">
                                <div className="col-span-full">
                                    <div className="text-2xl font-bold mb-6">Remove Liquidity</div>

                                    <RadioToken name="FRAX" logo={FRAX} isSelected={FRAXSelected} handleClick={() => select("FRAX")} />
                                    <RadioToken name="DAI" logo={DAI} isSelected={DAISelected} handleClick={() => select("DAI")} />
                                    <RadioToken name="USDT" logo={USDT} isSelected={USDTSelected} handleClick={() => select("USDT")} />
                                    <RadioToken name="USDC" logo={USDC} isSelected={USDCSelected} handleClick={() => select("USDC")} />
                                </div>
                                <div className="mb-7">
                                    <div onClick={() => {
                                        setFRAXSelected(true);
                                        setUSDTSelected(true);
                                        setDAISelected(true);
                                        setUSDCSelected(true);
                                    }} className="dark:bg-dark-500 focus:outline-none w-full text-steel-300 rounded-lg radio-outline py-3 text-center btn cursor-pointer ">
                                        Combo
            </div>
                                </div>
                                <div className="transactionInfoItem grid-cols-5 sm:grid-cols-2 grid ">
                                    <div className="slippage text-steel-300 text-sm dark:text-white ">
                                        <span>Withdrawal Fees: 0-0.1% </span><span className></span>
                                    </div>
                                    <div className="hidden font-base">
                                        <div>
                                            <div className="relative mx-2">
                                                <div className="bg-gray-500 text-white text-xs rounded py-2 px-4 right-0 bottom-full text-center font-base">
                                                    The fee diminishes to 0% over the course of a month
                    <br />after you first provide liquidity.<svg className="absolute text-gray-500 h-2 w-full left-0 top-full" x="0px" y="0px" viewBox="0 0 255 255">
                                                        <polygon className="fill-current" points="0,0 127.5,127.5 255,0" />
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex justify-center">
                                    {approvedLP === true ? 
                                    <div className="w-full text-center pt-5 ">
                                    <button className=" focus:outline-none w-full  text-white  py-3 rounded-lg shadow-sm bg-gradient-to-r from-blue-400 to-green-300">
                                        Approve
          </button>
                                </div> :
                                <div className="w-full text-center pt-5 ">
                                <button className=" focus:outline-none w-full  text-white  py-3 rounded-lg shadow-sm bg-gradient-to-r from-blue-400 to-green-300">
                                    Wtihdraw
      </button>
                            </div>
                                }
                                    
                                    
                                </div>
                                <div className="transactionInfoContainer mt-4 mb-3 text-steel-300 show">
                                    <div className="transactionInfo text-center text-sm">
                                        <span className="text-red-400" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-span-full sm:col-span-1 w-full">
                        <div className="dark:bg-dark-700 dark:text-white bg-white rounded-3xl shadow-md mb-6">
                            <div className="myShareCard ">
                                <div className="dark:text-white dark:border-b-dark-500 flex items-center border-b p-6 pb-2 lg:px-12 ">
                                    <div className="pb-2 mr-4">
                                        <div style={{ display: 'inline-block', maxWidth: '100%', overflow: 'hidden', position: 'relative', boxSizing: 'border-box', margin: 0 }}>
                                            <div style={{ boxSizing: 'border-box', display: 'block', maxWidth: '100%' }}>
                                                <img alt aria-hidden="true" role="presentation" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2ZXJzaW9uPSIxLjEiLz4=" style={{ maxWidth: '100%', display: 'block', margin: 0, border: 'none', padding: 0 }} />
                                            </div>
                                            <img src={bankAccount} decoding="async" style={{ visibility: 'inherit', position: 'absolute', inset: 0, boxSizing: 'border-box', padding: 0, border: 'none', margin: 'auto', display: 'block', width: 0, height: 0, minWidth: '100%', maxWidth: '100%', minHeight: '100%', maxHeight: '100%' }} srcSet={bankAccount} />
                                        </div>
                                    </div>
                                    <div>
                                        <div className="dark:text-white text-xl font-bold mb-1">Total</div>
                                        <div className="text-2xl text-blue-400 font-bold">{oneTokenBalance}</div>
                                    </div>
                                </div>
                                <div className="dark:bg-dark-700 dark:text-white dark:border-b-dark-500 items-center border-b p-6 text-sm">
                                <div className="grid grid-cols-2 ">
                                        <span className="text-steel-300 dark:text-white">Total amount : &nbsp; </span><span className="font-bold text-right"><span><span className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">0.0‌</span></span></span>
                                    </div>
                                </div>
                                <div className="dark:text-white items-center p-6 pb-3 text-sm">
                                    <div className="grid grid-cols-2 mb-4">
                                        <div className="grid grid-cols-2">
                                            <span><img src={FRAX} width="25px" style={{float:'left', marginRight: '3px'}}/><span style={{lineHeight: '25px'}} className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">FRAX : </span></span>
                                        </div>
                                        <span className="font-bold text-right"><span><span className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">‌0.0</span></span></span>
                                    </div>
                                    <div className="grid grid-cols-2 mb-4">
                                        <div className="grid grid-cols-2">
                                            <span><img src={DAI} width="25px" style={{float:'left', marginRight: '3px'}}/><span style={{lineHeight: '25px'}} className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">DAI :</span></span>
                                        </div>
                                        <span className="font-bold text-right"><span><span className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">0.0‌</span></span></span>
                                    </div>
                                    <div className="grid grid-cols-2 mb-4">
                                        <div className="grid grid-cols-2">
                                            <span><img src={USDT} width="25px" style={{float:'left', marginRight: '3px'}}/><span style={{lineHeight: '25px'}} className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">USDT :</span></span>
                                        </div>
                                        <span className="font-bold text-right"><span><span className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">‌0.0</span></span></span>
                                    </div>
                                    <div className="grid grid-cols-2 mb-4">
                                        <div className="grid grid-cols-2">
                                            <span><img src={USDC} width="25px" style={{float:'left', marginRight: '3px'}}/><span style={{lineHeight: '25px'}} className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">USDC :</span></span>
                                        </div>
                                        <span className="font-bold text-right"><span><span className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">‌0.0</span></span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="dark:bg-dark-700 dark:text-white bg-white rounded-3xl shadow-md mb-6">
                            <div className="myShareCard ">
                                <div className="p-6  lg:px-8 ">
                                    <div className="text-2xl font-bold">Recomended Stakes</div>
                                    <div className="flex py-6 pb-3 justify-between">
                                        <div className="flex items-center">
                                            <div style={{ display: 'inline-block', maxWidth: '100%', overflow: 'hidden', position: 'relative', boxSizing: 'border-box', margin: 0 }}>
                                                <div style={{ boxSizing: 'border-box', display: 'block', maxWidth: '100%' }}>
                                                    <img alt aria-hidden="true" role="presentation" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDQiIGhlaWdodD0iNDQiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIi8+" style={{ maxWidth: '100%', display: 'block', margin: 0, border: 'none', padding: 0 }} />
                                                </div>
                                                <img src={USTPool} decoding="async" style={{ visibility: 'inherit', position: 'absolute', inset: 0, boxSizing: 'border-box', padding: 0, border: 'none', margin: 'auto', display: 'block', width: 0, height: 0, minWidth: '100%', maxWidth: '100%', minHeight: '100%', maxHeight: '100%' }} srcSet={USTPool} />
                                            </div>
                                            <div className="ml-2">
                                                <div className="font-bold text-lg">StableGaj LPs</div>
                                                <div className="text-blue-400 text-sm font-bold ">
                                                    <span><span className="react-loading-skeleton css-1q79kkk-skeletonStyles-Skeleton">‌</span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <a href="/Stake"><button className="focus:outline-none w-full  text-white  py-3 px-8 rounded-lg shadow-sm bg-gradient-to-r from-blue-400 to-green-300">
                                                Stake Now
                  </button></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Footer />
        </div>

    )
}

export default WithdrawUST;