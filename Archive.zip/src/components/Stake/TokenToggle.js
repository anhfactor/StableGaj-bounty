import {useState} from 'react'
function TokenToggle(props) {
    const [isActive, setIsActive] = useState(false);

    return (<div className="dark:bg-dark-700 dark:border-0 border-t relative dark:border-t-dark-500">
        <div onClick={()=>setIsActive(!isActive)} className="grid grid-cols-5  sm:gap-2 cursor-pointer">
            <div className="flex col-span-2 py-2 sm:py-6 sm:px-4 justify-between items-center">
                <div className="text-xs flex items-center">
                    <div className="flex mx-2 sm:mx-0 sm:mr-4">
                        <div className="flex sm:hidden relative z-10">
                            <div style={{ display: 'inline-block', maxWidth: '100%', overflow: 'hidden', position: 'relative', boxSizing: 'border-box', margin: 0 }}>
                                <div style={{ boxSizing: 'border-box', display: 'block', maxWidth: '100%' }}>
                                    <img alt aria-hidden="true" role="presentation" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIi8+" style={{ maxWidth: '100%', display: 'block', margin: 0, border: 'none', padding: 0 }} />
                                </div>
                                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" decoding="async" style={{ visibility: 'hidden', position: 'absolute', inset: 0, boxSizing: 'border-box', padding: 0, border: 'none', margin: 'auto', display: 'block', width: 0, height: 0, minWidth: '100%', maxWidth: '100%', minHeight: '100%', maxHeight: '100%' }} />
                            </div>
                        </div>
                        <div className="hidden sm:flex relative z-10">
                            <div style={{ display: 'inline-block', maxWidth: '100%', overflow: 'hidden', position: 'relative', boxSizing: 'border-box', margin: 0 }}>
                                <div style={{ boxSizing: 'border-box', display: 'block', maxWidth: '100%' }}>
                                    <img alt aria-hidden="true" role="presentation" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIi8+" style={{ maxWidth: '100%', display: 'block', margin: 0, border: 'none', padding: 0 }} />
                                </div>
                                <img src={props.logo} decoding="async" style={{ visibility: 'inherit', position: 'absolute', inset: 0, boxSizing: 'border-box', padding: 0, border: 'none', margin: 'auto', display: 'block', width: 0, height: 0, minWidth: '100%', maxWidth: '100%', minHeight: '100%', maxHeight: '100%' }} srcSet={props.logo} />
                            </div>
                        </div>
                    </div>
                    <div className="text-xs sm:text-lg font-bold dark:text-white">
                        <div>
                            {props.name}<span className="undefined rounded-lg text-white bg-pink-500 px-1 sm:px-2 ml-1 sm:px-3 sm:text-base text-xs">0X</span>
                        </div>
                        <div className="font-light text-xs cursor_pointer text-blue-500 ">
                            <a target="_blank" href="https://exchange.pancakeswap.finance/#/add/0xff54da7caf3bc3d34664891fc8f3c9b6dea6c7a5/0x844FA82f1E54824655470970F7004Dd90546bB28">Add {props.name}</a>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-span-1 flex items-center justify-center">
                <div className="text-center text-xs px-2 sm:text-base dark:text-white font-bold py-1 rounded-lg text-black">
                    APR <span className="sm:inline hidden">: </span>{props.APR}%
<div className="text-xs text-center text-steel-300">≈ {props.APRDaily}% daily</div>
                </div>
            </div>
            <div className="col-span-1 text-xs sm:text-base dark:text-white flex items-center justify-center">
                ${props.TVL}
</div>
            <div className="text-blue-400 font-bold text-center sm:text-left text-xs sm:text-lg flex items-center justify-center">
                0.00
</div>
        </div>
        <div className={`${isActive?'active':''} card-toggle`}>
            <div className="dark:bg-steel-500 py-3 sm:py-0 grid grid-cols-8 border-t dark:border-0 bg-gray-100 ">
                <div className="col-span-full sm:col-span-3 sm:py-6 px-3 sm:pl-6 sm:pr-3 grid grid-cols-1 sm:gap-y-1">
                    <div className="flex justify-between items-center">
                        <div className="dark:text-white font-bold text-gray-500 text-md">
                            Stake
</div>
                        <div className="text-gray-400 text-xs sm:text-sm flex">
                            <div>Balance:</div>
                            <div className="ml-1 cursor-pointer text-blue-500">0.00</div>
                        </div>
                    </div>
                    <div className>
                        <input type="number" placeholder={0} className="dark:bg-dark-400 dark:text-white focus:outline-none focus:ring focus:border-blue-200 rounded-md p-2 w-full mb-1 sm:mb-0 sm:my-3" readOnly defaultValue />
                    </div>
                    <div className="-mt-10 pr-1">
                        <button className="dark:bg-dark-500 focus:outline-none text-blue-400 bg-blue-100 px-5 py-1 rounded-md float-right relative z-1">
                            Max
</button>
                    </div>
                    <div className="mt-1">
                        <div className="flex gap-3">
                            <button type="button" className="focus:outline-none text-center py-2 mt-1 w-full border-0 rounded-md font-bold bg-blue-400 text-white">
                                Approve</button><button type="button" className="focus:outline-none text-center py-2 mt-1 w-full bg-steel-200 rounded-md font-bold dark:text-dark-700 text-gray-400 dark:bg-dark-500" disabled>
                                Deposit
</button>
                        </div>
                    </div>
                    <div className=" mt-4 text-xs dark:text-gray-400 flex items-center justify-center">
                        <span className="mr-1">You don’t have LP token yet? </span><a target="_blank" href="https://exchange.pancakeswap.finance/#/add/0xff54da7caf3bc3d34664891fc8f3c9b6dea6c7a5/0x844FA82f1E54824655470970F7004Dd90546bB28"><span className="text-blue-400">Add LP</span></a>
                    </div>
                </div>
                <div className="col-span-full sm:col-span-3 py-4 sm:py-6 pl-3 pr-3 grid grid-cols-1 sm:gap-y-1">
                    <div className="flex items-center justify-between">
                        <div className="dark:text-white font-bold text-gray-500 text-md">
                            Unstake
</div>
                        <div className="text-gray-400 text-xs sm:text-sm flex">
                            <div>Balance:</div>
                            <div className="ml-1 cursor-pointer text-blue-500">0.00</div>
                        </div>
                    </div>
                    <div className>
                        <input type="number" placeholder={0} className="dark:bg-dark-400  dark:text-white focus:outline-none focus:ring focus:border-blue-200 rounded-md p-2 w-full mb-1 sm:mb-0 sm:my-3" readOnly defaultValue />
                    </div>
                    <div className="-mt-10 pr-1">
                        <button className="dark:bg-dark-500 focus:outline-none text-blue-400 bg-blue-100 px-5 py-1 rounded-md float-right relative z-1">
                            Max
</button>
                    </div>
                    <div className="mt-1">
                        <div className="flex gap-2">
                            <button type="button" className="focus:outline-none text-center py-2 mt-1 w-full rounded-md font-bold bg-blue-400 text-white">
                                Approve</button><button type="button" className="focus:outline-none text-center py-2 mt-1 w-full rounded-md bg-steel-200 font-bold dark:text-dark-700 text-white text-gray-400 dark:bg-dark-500" disabled>
                                Withdraw
</button>
                        </div>
                    </div>
                    <div className=" mt-4 text-xs dark:text-gray-400 flex items-center justify-center">
                        <span className="mr-1">You want remove LP token? </span><a target="_blank" href="https://exchange.pancakeswap.finance/#/remove/0xff54da7caf3bc3d34664891fc8f3c9b6dea6c7a5/0x844FA82f1E54824655470970F7004Dd90546bB28"><span className="text-blue-400">Remove LP</span></a>
                    </div>
                </div>
                <div className="col-span-full sm:col-span-2 text-center p-5 pl-3 grid grid-cols-1 gap-y-1">
                    <div className="text-total-reward text-3xl font-bold text-blue-500 pt-4 flex justify-center items-center">
                        0.00
</div>
                    <div className="dark:text-white text-xs mb-4">(≈ $0.00)</div>
                    <button type="button" className="focus:outline-none text-center my-1  w-full py-3 sm:py-2 rounded-md bg-gradient-to-r from-blue-400 to-green-300 text-white font-bold sm:mb-10">
                        Claim
</button>
                </div>
            </div>
        </div>
    </div>)
}

export default TokenToggle;